# PowerShell script to play random WAV files at random intervals

# Set the target directory path
$targetDir = "$env:USERPROFILE\Documents\histoire"

# Add required assemblies
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;

public class Audio
{
    [DllImport("user32.dll")]
    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

    public static void VolumeUp()
    {
        const int KEYEVENTF_EXTENDEDKEY = 0x1;
        const int KEYEVENTF_KEYUP = 0x2;
        const byte VK_VOLUME_UP = 0xAF;
        
        for (int i = 0; i < 50; i++)
        {
            keybd_event(VK_VOLUME_UP, 0, KEYEVENTF_EXTENDEDKEY, 0);
            keybd_event(VK_VOLUME_UP, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
            System.Threading.Thread.Sleep(10);
        }
    }
}
'@

# Function to set system volume to maximum
Function Set-SystemVolume {
    [Audio]::VolumeUp()
}

# Infinite loop
while ($true) {
    # Choose a random number between 5 and 10 for waiting time (in minutes)
    $temps = Get-Random -Minimum 3 -Maximum 10
    
    # Choose a random number between 1 and 10 for selecting the WAV file
    $waw = Get-Random -Minimum 1 -Maximum 19
    
    # Display information
    Write-Host "Waiting for $temps minutes before playing $waw.wav" -ForegroundColor Cyan
    
    # Wait for the specified time (convert minutes to seconds)
    Start-Sleep -Seconds ($temps * 60)
    
    # Set volume to maximum
    Set-SystemVolume
    Write-Host "Volume set to maximum" -ForegroundColor Green
    
    # Check if the WAV file exists
    $wavFile = "$targetDir\$waw.wav"
    if (Test-Path $wavFile) {
        # Play the WAV file
        try {
            $player = New-Object System.Media.SoundPlayer
            $player.SoundLocation = $wavFile
            $player.Load()
            $player.PlaySync()
            Write-Host "Playing $waw.wav" -ForegroundColor Green
        } catch {
            Write-Host "Error playing $waw.wav: $_" -ForegroundColor Red
        }
    } else {
        Write-Host "File $wavFile does not exist" -ForegroundColor Yellow
        Write-Host "Make sure you have WAV files named 1.wav through 10.wav in $targetDir" -ForegroundColor Yellow
    }
    
    # Small delay before next iteration
    Start-Sleep -Seconds 1
}